- **Premium** (14): age-detection, bataljadibot, ewe, ewepaksa, fstik, gpt2image, kasedaiki, nanobananapro, numbgen, swhdv2, swhdv3, swhdv4, talkingphoto, ytsummarize

- **ai** (46): ai-leaderboard, aifilter, ainsfw, aivideo, arta, bocchi, chatgot, chatsmith, claudepro, copilot, dpsteai, editimage2, elainaai, faceswap, furina, glm4, gpts, hoshino, hoshinoaivn, hsnaibanana, humanize, hutao, kilua, kimi, kimi-vision, kita, luffyai, mahiru, makima, meguminai, mikasa, mikuai, mistral, nijika, oguri, rimuru-ai, rimuru-blackbox, rimurubanana, rimurubanana2, roboguru, sora2, summarize, vemzo-ai, vemzobanana, vemzobanana2, webpilot

- **anime** (25): anichin, anilist, anime-waifu, waifu-anime, animedate, animedl, animelatest, animereco, animeseason, animetrailer, animewall, anischedule, autoanimewinbu, character, fotorandom002, ikiru, konachan, kusonime, loli, mobinime, rekom-anime, shinigamidetail, stor, tokusatsu, wuwa, yande

- **asupan** (1): santuy

- **canvas** (33): boardingpass, calledit, dbmeme, fakeatm, fakecallwa, fakedj, fakeidcard, fakeijazah, fakeijin, fakeimgios, fakekarcis, fakekartupelajar, fakengl, fakenikah, fakepaspor, fakesertifikat, fakesp, faketiket, gojo, iqc5, iqcmerah, juarabadminton, meme1, meme2, meme3, menumedia, movieposter, oh-no, pacarsertifikat, susutaro, tobrooklyn, vos, vosv2

- **clan** (18): clanbank, clanboss, clancheckin, clandemote, clandesc, clanlevel, clanlogo, clanpromote, clanraid, clanraidjoin, clanrank, clanrename, clanreport, clanupgrade, clanwaraccept, clanwarhistory, clanwarscore, clanxp

- **colorgrade** (3): cc1, cc2, cc3

- **database** (4): delcmd, listcmd, setcmd, unlockcmd

- **download** (10): kraken, ssdl, tiktokdl, tiktokdl2, tiktokdoc, ttimg, ttmusic, ttslide, xhs, ytpost

- **downloader** (3): aio2, tiktokboost, tt4

- **downloads** (1): gimage

- **economy** (4): leaderboard-orang-kaya, leaderboard-orang-miskin, rimuru-nguli, riyal

- **ephoto** (1): ephoto

- **fun** (35): angka, artinama2, autorimuru, benarkah, burik, carabalikan, cekiq, cekkontol, cekmemek, cekotot, cekperforma, dimanakah, gachabini, gachafemboy, gachaistri, gachanasip, gachasuami, gachatomboy, gojoquote, halah, jomok, kapankah, kematian, kulitkerang, lifefact, lupakan, moveon, pasanganku, ramal, seberapagila, simi2, suratcinta, tebakumur, todgame, wa-canvas

- **game** (46): attack, battleship, battleshipmp, benaratausalah, blockade, checkers, genshinprofile, hint, kjzo, lengkapikalimat, maths, mlbb, nyerah, othello, perangsarung, pinzo, pixzo, quoridormp, siapakahaku, sos, survival, susunkata, tebakanime, tebakanml, tebakbenda, tebakbola, tebakbuah, tebakdrakor, tebakff, tebakgambar, tebakgame, tebakgd, tebakhewan, tebakkalimat, tebakkimia, tebaklagu, tebaklirik, tebaklogo, tebakmakanan, tebaknegara, tebakpikiran, tebakprofesi, tictactoev2, xozo, zonic, zonicv2

- **group** (39): addcmdsticker, antilinkch, antilinkkick, antitagall, antivirtex, autokilua, botmodegc, cekasalmember, cekonlyadmin, cidukdelmsg, delblacklist, getppgc, groupadmin, groupsecurity, groupstats, groupsummary, kickall, leavegc, listmember, listwar, mampir, notifmakan, notiftidur, onlyadmingc, removeall, resettopaktif, risetsider, setantilinkkick, setbye, settop, spamclose, spamtag, swapadmin, tagmember, tagsider, unpin, upsw, upswgc, upswgcv2

- **image** (6): animehot, imageloli, imagepapayang, iqcv3, shota, uhdpaper

- **info** (12): benefitpartner, bmkggempa, buildml, callingcode, hok, listhero, market, nasaname, pengguna, topfitur, totalfitur2, wwchar

- **internet** (7): antara, cnbc, dongeng, fdroid, gimg, kbbi, wallcraft

- **islamic** (1): murothal

- **jpm** (12): autojpm, blacklistjpm, blautojpm, jpm, jpmalbum, jpmbasic, jpmch, jpmht, jpmupdate, setdelayjpm, stopjpm, stopjpmbasic

- **main** (14): @verify, benefitowner, benefitpremium, creator2, credit, gbbot, hargabot, listmenu, menuhsn, menuhtml, saluran, seleksif02, sewa2, tqto2

- **maker** (49): autocrop, bratkilua, carbonlocal, cinematic, dictreveal, fakebca, fakeboard, fakebook, fakedownload, fakeff3, fakeffduo <nama1|nama2>, fakegroup, fakegroupv2, fakeigstory, fakeml2, fakenote, fakenotifwa, fakett, fch, fkebca, fq2, hangingpolaroid, hazzard, hotline, iqc3, iqcsticker, jail, kolasenama, logo-3d, logo-glow, logo-gold, logo-metal, noteig, notesanime, pinkgreen, pov, quotecard, quotephoto, sertifikatcinta, sertifikatlemot, sertifikatnasa, textlogo, toblonde, tosdmtinggi, wanted, wasted, web2apk, wmp1, wmp2

- **media** (1): setaudio

- **music** (3): play-zero, playncs, ringtone

- **nsfw** (2): oppai, randomhentai

- **owner** (162): addam, addfile, addfiledb, addgacha, addjpg, addmedia, addmp3, addmp4, addscraper, ambilfile, ambilfolder, antipm, arsip, autobio, autoclean, autopagi, autopost, autosiang, autovidpagi, bankategori, banuser, bcgc, blacklist, blacklistgc, buatsaluran, carinamaplugin, cat, cekschedule, checkerror, consolelog, controlgrup, createchannel, dbquery, delam, delfile, delfiledb, delmedia, deluserall, followch, gamemode, ganti-hsnai-allmenu.jpg, ganti-hsnai-demote.jpg, ganti-hsnai-levelup.jpg, ganti-hsnai-otp.jpg, ganti-hsnai-promote.jpg, ganti-hsnai-reply-v4.mp4, ganti-hsnai-v10.jpg, ganti-hsnai-v11.jpg, ganti-hsnai-v12.jpg, ganti-hsnai-v13.jpg, ganti-hsnai-v14.jpg, ganti-hsnai-v16.jpg, ganti-hsnai-v22.jpg, ganti-hsnai-v7.jpg, ganti-hsnai-v8.jpg, ganti-hsnai-v9.jpg, ganti-hsnai-winner.jpg, ganti-hsnai.jpg, ganti-hsnai.mp3, ganti-hsnai.mp4, ganti-hsnai2.jpg, ganti-hsnai3.jpg, ganti-rimuru-demote.jpg, ganti-rimuru-levelup.jpg, ganti-rimuru-promote.jpg, ganti-rimuru-v8.jpg, ganti-rimuru-winner.jpg, ganti-rimuru.jpg, ganti-rimuru.mp3, ganti-rimuru.mp4, ganti-rimuru2.jpg, ganti-rimuru3.jpg, ganti-sea.jpg, ganti-vemzo-demote.jpg, ganti-vemzo-levelup.jpg, ganti-vemzo-promote.jpg, ganti-vemzo-v8.jpg, ganti-vemzo-winner.jpg, ganti-vemzo.jpg, ganti-vemzo.mp3, ganti-vemzo.mp4, ganti-vemzo2.jpg, ganti-vemzo3.jpg, ganti-zann.jpg, gantiapi, ganticode, gantifile, gantiidsaluran, gantilinksaluran, gantiscraper, getfiledb, getjpg, getmp3, github, hapussaluran, hapususer, healthcheck, hsnai-large, iklan, integritytest, ipleak, jpmslide, liatgacha, listam, listjadibot, listjadibotaktif, listplugin, maintenance, map, menuaudiostyle, notifch, oadd, offenergi, onlyowner, openvoown, otakatik, plugindiff, pluginhealth, pluginlog, ratelimitlog, reactevent, remoteleave, rename, renamepg, rimuru-large, rimuru-otp, savebotch, schedulebroadcast, searchplugin, sendasset, setallmenu, setbell, setcontext, setdelay, setgetplugin, setgreettype, setinfoplugin, setkoin, setmenuhsn, settiktokdl2, settqto, setversi, sharetoch, sitagrup, snippet, speedtest, star, startschedule, stop, stopalljadibot, stopdandeletejadibot, stopschedule, testplugin, toeval, toggle-energi, unbanuser, upaudioch, updatescript, uppreset, vardump, vemzo-large, whitelistgc

- **panel** (8): addseller, cekjeda, cpanel, installtemabilling, installtemaenigma, installtemanebula, installtemastellar, jedacreate

- **premium** (3): jadibot, netflixprem, stopjadibot

- **pushkontak** (2): pushkontak, pushkontak2

- **quotes** (2): quotebucin, sadboy

- **random** (5): cosba, pantun2, q-islam, randomname, superhero

- **religi** (15): alkitab, autosahur, ayat, istighfar, istikharah, mandiwajib, nisfusyaban, puasa, rajab, ramadhan2027, sholawat, surah2, tahlil, taubat, zikir

- **rich** (1): tiktoksc

- **rpg** (49): 7eleven, achieve, addrpg, airdrop, akuntiktok, akunyt, bagiuang, bankcek, bansos, berdagang, bossbattle, bunuh, claim, collect, cooldown, createakun, creatett, dailyrpg, deps, expoint, fightnaga, fightphonix, freelimit, gaji, idolku, karung, koboy, listbuah, livett, membunuh, merampok, merpg, minecraftbattle, mulai, pelabuhan, polisi, rank, reedem, resetbansos, roket, sawer, simulator, skill, taksi, taxy, tembak2, upgradeatm, warnet, warteg

- **search** (42): animelink, apkcombo, apkpure, apkzoic, applemaps, applemusicsearch, brainly, carianime, clip, douyinsearch, dramabox, gdleaderboard, getmusik, grupwasearch, happymodsearch, imdb, infoloker, jobstreetsearch, kodepos, mangalist, mangaread, mcaddons, meigen, mltour, objectgeometrydash, pindlrich <search> <jumlah>, pins, pins2, pinsrich, play4, playstore, playstoresearch, promptsearch, putar-play2, searchcode, searchgd, soundmeme2, stikerwa, tgram, toproblox, uptodown, webtoonsearch

- **stalker** (9): daftartiktok, gddaily, levelgd, mcavatar, stalkcoc, stalkgd, stalkxnxx, ytpoststalk, ytvidstalk

- **sticker** (22): bratanime2, bratanime3, bratanime4, bratblueai, bratcewek2, bratemon, bratfilter, bratrb, cewek, img2sp, kannabrat, menusticker, ryo, slock, smemecode, squid, tekss, teksvid, teksvid2, telestick, tostickerpack, upin

- **store** (17): addstok, beliproduk, cancelorder, cancelproses, confirmorder, delorder, done, editlist, editstok, hapusstok, liststok, myorder, productinfo, proses, setdone, setproses, simulatepay

- **store_autoorder** (9): autoaddstok, autobeli, autocekstok, autohapusproduk, autohapusstok, autolistproduk, autotambahproduk, kurangisaldo, tambahsaldo

- **testing** (1): testall

- **tools** (101): addsong, alultimate, am-data, amsend, amverif, audionoicereducer, bitly, blur, breach, casetoplugin, ceknamadana, cekrek, cekusername, checkhost, claudeshare, cleanslash, colongsw, convert file, dbinary, debiner, dec, doc, ebinary, ekspedisilist, enlargerai, facedetector, fagsocial, fagsocial_video, fakeall, fakecam, fakecamvid, fakepoll, fakesw, faketag, fakevhs, fetchweb, ffguest, fkontak, fliptext, gencard, gepeng, getppchannel, ghuser, grammarly, gsmarena2, hd4, hd5, hd8, hostmedia, htmltoeksekusi, imagetoasci, jadian, jadwaltv, jarak, kirimpesangc, linkid, lonjong, mcstalk, mcstatus, mikutalk, myip, nftoken, nftools, npmdl, npmshield, otpbomb, pdf2img, plugintocase, potongsound, preset, promptcode, proxy, qrcodefile, readqr, resizevideo, scanrepo, searchgist, shareteks, spamotp, spotivid, sstablet, ssweb-3hasil, struk, suppbypass, swhd, tebalteks, tesautopostch, textidentify, timeis, tocodeqr, toesm, tojadul, tran, ttsprabowo, tweetss, up-pb, upch2, usernamegen, vgist, web2zip, whatsappme

- **tts** (6): holotts, ttseminem, ttsgoku, ttsmickey, ttsnahida, ttsvoice

- **user** (2): hastag, referal

- **voice** (1): tempo

- **xp** (1): unregister