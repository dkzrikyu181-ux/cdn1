# Porting fitur ke vanXone — ringkasan

Dibuat otomatis: 848 fitur baru diambil dari VEMZO-MD, Rimuru MD, Hoshino Ai Bot, dan
Kilua MD (By Naren), lalu digabung ke script vanXone kamu. Furina tidak sempat diproses
(sebagian besar isinya ter-obfuscate/terenkripsi sehingga butuh sesi terpisah untuk dibongkar).

## Cara kerja porting ini
1. Semua command yang **sudah ada** di vanXone (3.514 command) dilewati — tidak di-import ulang.
2. Kalau fitur yang sama ada di lebih dari satu script donor (±109 nama fitur), dipilih **satu
   versi terbaik** (prioritas: aktif/tidak di-disable, paling sedikit butuh API key eksternal,
   kode paling lengkap). Jadi tidak ada command dobel.
3. Konten NSFW (`nekopoi`) sengaja **tidak** di-port.
4. Fitur baru ditaruh di folder terpisah supaya gampang dicek/dihapus kalau perlu:
   - `vemzo/` — hasil dari VEMZO-MD (39 fitur)
   - `rimuru2/` — hasil dari Rimuru MD (518 fitur)
   - `hoshino2/` — hasil dari Hoshino Ai Bot (221 fitur)
   - `kilua2/` — hasil dari Kilua MD By Naren (70 fitur, arsitektur beda jadi pakai adapter sendiri)
   - Command-nya didaftarkan lewat stub kecil di `plugins/vemzo/`, `plugins/rimuru2/`,
     `plugins/hoshino2/`, `plugins/kilua2/` — persis gaya `plugins/ourin/` yang sudah ada di
     script kamu sebelumnya.
5. Adapter baru: `lib/portkit.js` (dipakai VEMZO/Rimuru/Hoshino, formatnya mirip Ourin jadi
   satu adapter generik) dan `lib/kilua2.js` (beda arsitektur, bikin objek `conn` tiruan).
   Keduanya numpang fungsi `sock` tambahan (kirim stiker/media dll) dan identitas bot dari
   sistem Ourin yang sudah ada, supaya tidak duplikat kode.
6. Semua penyebutan nama bot asal (Hoshino Ai, Rimuru-MD, VEMZO-MD, By Naren) sudah diganti
   jadi **vanXone** di teks balasan.
7. Kalau satu fitur gagal dimuat (misal butuh package npm yang belum ter-install), bot akan
   balas pesan error yang jelas ke user, bukan crash — command lain tetap jalan normal.

## Sudah dites
- Semua 848 file baru (stub + kode asli) lolos `node --check` (tidak ada syntax error).
- Simulasi `loadPlugins()` penuh: 2.448 dari 2.473 command ke-load, dan **0 kegagalan berasal
  dari fitur baru** — 25 yang gagal murni plugin asli vanXone yang butuh `npm install` di
  sandbox pengetesan (cheerio, form-data, dll — sudah ada di `package.json` kamu, cuma belum
  ter-install di tempat aku ngetes).

## Yang perlu kamu lakukan setelah extract
1. **Jalankan `npm install` seperti biasa** di server/panel kamu (dependency utama sudah ada
   di `package.json`, tidak aku ubah).
2. Beberapa fitur (jumlahnya kecil) butuh package tambahan yang belum ada di `package.json`
   vanXone kamu. Kalau mau dipakai, install manual:
   `npm install cron lru-cache qrcode ssh2 jimp bing-translate-api ytdl-core node-cron puppeteer-core @sparticuz/chromium gradient-string figlet cli-table3`
   Kalau tidak di-install, fitur yang butuh package itu cuma akan balas "dependensi belum
   terpasang" — command lain tidak kepengaruh.
3. Restart bot seperti biasa.

## Daftar lengkap 848 fitur baru (per kategori)
Lihat `PORTING_FITUR_LIST.md`.

## Pembersihan dobel & nama creator (sesi terakhir)
- Stub kembar (dua file stub menunjuk ke kode asli yang sama, mis. `X.js` dan `o-X.js` di ourin) digabung jadi satu: 149 file.
- Command yang sudah dimiliki fitur ori vanXone dihapus dari stub donor; stub yang semua command-nya sudah ada dihapus (63 stub) beserta kode asli donornya (58 file). 275 alias dobel dibuang.
- Hasil: 2.466 → 2.254 file plugin; command unik tetap 6.179 (tidak ada yang hilang), command dobel dari donor = 0.
- Nama creator lain di output (Anita Putri Azzahra, Ramzz X Cloud, Lucky Archz, Hilman, Mommy Kyuu, Amane Ofc, ZeroTwo Channel, OURIN GAMES/RPG, merek Rimuru/Hoshino/Ourin/Vemzo AI, dll) diganti `vanXone </>` / `vanXone`.
- Sisa dobel di fitur ori vanXone sendiri (sengaja tidak dihapus): `terima` dan `tolak` ada di `plugins/fun/anya-social.js` dan `plugins/store/produk.js`.

## Perbaikan playch & import baileys
- `lib/ffm.js`: error ffmpeg sekarang menyertakan pesan stderr, jadi penyebab gagal kelihatan.
- `lib/sahril/playch.js`: `Toptt` mengecek hasil unduhan (kosong / halaman error) dan mencoba beberapa encoder opus.
- Import `from 'rimuru'` / `from 'ourin'` di rimuru2 dan vemzo diganti ke `@whiskeysockets/baileys` (paket `rimuru`/`ourin` tidak ada, bikin plugin gagal dimuat, mis. owner/createchannel).

## playch: mesin unduh berlapis
- `lib/sahril/playch.js` `downloadYoutube` mencoba berurutan: Savetube, loader (savenow), ytultra, yt-dlp. Tiap hasil divalidasi (bukan halaman error / file kosong) sebelum dipakai; log `[PLAYCH] audio via ...` menunjukkan mesin yang berhasil.

## Perbaikan fitur rusak (sesi cek menyeluruh)
- `hsnai`, `rimuru`, `ourin`, `@itsliaaa/baileys` bukan paket npm yang ada -> 61 file (hoshino2, rimuru2, vemzo) sekarang import ke `lib/baileys-compat.js` / `lib/baileys-compat.mjs` (isinya Baileys yang sudah terpasang). Sebelumnya ±70 fitur gagal dengan "Dependensi belum terpasang".
- `package.json`: ditambah `optionalDependencies` untuk paket yang dipakai fitur donor (cron, lru-cache, lowdb, qrcode, jimp@0.22, ssh2, node-cron, request, crypto-js, socks-proxy-agent, @google/generative-ai, webcrack, mupdf, puppeteer-core, @sparticuz/chromium, cli-table3, figlet, gradient-string, ytdl-core, bing-translate-api). Jalankan `npm install` lagi.
- `config.js`: global `wait`, `eror`, `wm` dijamin ada (dipakai fitur rimuru2/anya sebagai variabel telanjang).
- Nama command yang mengandung spasi / `<>` (tidak pernah bisa ke-trigger) dirapikan: convertfile, waifu_anime, fakeidcard, fakeduoff, pin2.
- Bug variabel: war-attack & fightnaga (`i`/`unggul` tanpa deklarasi, crash di ESM), addmedia (`url` -> `finalUrl`), anya/webp (`cusor`), anya/simple (`S_WHATSAPP_NET`).

## Perbaikan tahap 2 (play, totalfitur, registry donor)
- `.play` ditulis ulang: kirim kartu gambar biasa (selalu terkirim, tidak bergantung tombol interaktif) lalu langsung kirim audio. Video: `.ytmp4 <link>`.
- `.ytmp3` / `.ytmp4` sekarang memakai `lib/mediadl` (scriptmind -> ytultra -> savetube -> loader.to -> cobalt -> yt-dlp). Satu server mati = otomatis pindah ke server lain; pesan gagal menampilkan detail tiap mesin.
- `.totalfitur` (plugins/info/totalfitur.js) menghitung dari registry plugin bot yang sebenarnya. Sebelumnya dari `global.plugins` milik adapter anya yang selalu kosong -> 0.
- `lib/donorregistry.js` + patch `rimuru-plugins.js`, `vemzo-plugins.js`, `hoshino2/src/lib/plugins.js`: fitur donor yang menghitung/menampilkan daftar plugin (totalfitur2, benefitowner, benefitpremium, searchplugin, dst.) tidak lagi membaca tabel kosong.
- `rimuru2/config.js`: ekspor `RIMURU_CORE_CONFIG` & `RIMURU_DEVELOPER` (8 fitur gagal dimuat tanpa ini: ai-leaderboard, wa-canvas, setversi, sharetoch, upaudioch, autosahur, telestick, proses).
- `survival.js` (rimuru2): `sock`/`users` diteruskan ke event acak; `war-attack`/`fightnaga`: loop `for (let i ...)`.

## Auto-install dependency (panel)
- `lib/bootstrap.js` dipanggil paling awal oleh `bot.js`. Kalau `node_modules` belum ada (user cuma upload script lalu klik Start), bot menjalankan `npm install` sendiri, lalu lanjut menyala. Kalau install massal gagal, paket dipasang satu per satu; hanya paket inti (baileys, boom, pino, axios) yang bikin bot berhenti dengan pesan jelas.
- `index.js` ditambahkan sebagai alias entry point (`require('./bot')`) untuk panel yang memakai index.js sebagai file utama.
- Saran panel: RAM minimal 1GB dan disk 2GB untuk proses install pertama; start command cukup `node bot.js`.
