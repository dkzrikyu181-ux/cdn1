/**
 * WhatsApp Channel Reaction (VIP) - VANXONE PLUGIN
 * Creator: IzzXd (converted for vanXone)
 * API: https://reactionwa.online/
 */

const fs = require('fs');
const path = require('path');
const axios = require('axios');

const API_ENDPOINT = 'https://apiv2.reactionwa.online/api/v2/react';
const CACHE_DIR = path.join(__dirname, '.cache');
const STATE_FILE = path.join(CACHE_DIR, 'rch_vip_state.json');
const LINK_REGEX = /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([A-Za-z0-9_-]+)\/(\d+)/i;
const EMOJI_REGEX = /\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?/gu;

const DEFAULT_VIP_KEYS = [
    { name: 'VIP-G3FA579P', apiKey: 'BERRY-RCH-s488dmV/Im9CYK9RksIKzHB+PKpqxaGBeDje9boybZoMiEoWLc1EmGG2TA9yTgBOCa9RT56a35exUMwqJG06QTO39LJvF7IWZCVq3FKzME50TUNgJH4=', domain: 'https://berrymodapk.com' },
    { name: 'VIP-VIP-D68J', apiKey: 'BERRY-RCH-UF0CX6Lc+ncL7W/kQldo2v+uKbXtjyqhRg6z/u/GJaoL41jILpCerrfSFQBGLSZnNqHvFrIJ5bnOnDTd2K102CgMulKWZfxGbeo/Fmf9Pi4w2mySyBf5dLAnaw==', domain: 'https://reactv2.zfile.web.id' },
    { name: 'VIP-D68JICP0', apiKey: 'BERRY-RCH-Eu3fhllDTNViiwl8dFcVKfMnJUzSt/UFLTftJ/sZJgPy/nCC3Y7JO+83gJLLhicfp+SEEhfruPHhIE3vJrr0oU5mhEfpa2GcBcC4A/GV9VaInumRoLsmSLjBskNQyVE=', domain: 'https://api.rech.v2.zfile.web.id' },
    { name: 'VIP-H9PQGDBA', apiKey: '5XJr5CoEvcwn6Akmx4TvQPV+ybnaa7VAn8OUYdociEXLS2l06kPypNMFhz5eMExSxrq+/mHz8sOu/5k44dEB016L/QJ3QZpPuYbDiSdpxlVTOR6a14P295M8lQrmMrj0YLJmmne1sQ+1YGhCKSg=', domain: 'https://anzzmodsofficial.edgeone.dev/reaction/wa' },
    { name: 'VIP-SYNOZG8C', apiKey: 'EmCRdHArrxyMxWgwZVbukIcXOFGgz05PleSnm/5E6lP/MNb9rI4R/fqR5ALvCRhe3Q0NmDMw7lBXprFV3w8jen1M', domain: 'https://reactionwa.online' }
];

function ensureCacheDir(){ if(!fs.existsSync(CACHE_DIR)){ try{ fs.mkdirSync(CACHE_DIR,{recursive:true}); }catch{} } }
function loadState(){ ensureCacheDir(); let s={keyIndex:0,keys:DEFAULT_VIP_KEYS}; if(fs.existsSync(STATE_FILE)){ try{ s=JSON.parse(fs.readFileSync(STATE_FILE,'utf8')); }catch{} } return s; }
function saveState(s){ ensureCacheDir(); try{ fs.writeFileSync(STATE_FILE,JSON.stringify(s,null,2)); }catch{} }
function normalizeUrl(u){ const m=String(u||'').match(LINK_REGEX); if(!m) return null; return `https://whatsapp.com/channel/${m[1]}/${m[2]}`; }
function parseEmojis(e){ const m=String(e||'').match(EMOJI_REGEX); if(!m) return null; return m.slice(0,5).join(', '); }

async function sendReactionRequest(t,r,k){
  const origin=k.domain==='*'?'https://reactionwa.online':k.domain;
  const referer=origin.endsWith('/')?origin:origin+'/';
  const res=await axios.post(API_ENDPOINT,{url:t,reaction:r},{
    headers:{'Content-Type':'application/json','Origin':origin,'Referer':referer,'x-api-key':k.apiKey,'User-Agent':'Mozilla/5.0'},
    timeout:45000
  });
  return res.data;
}

async function react(targetUrl,reactionInput){
  const start=Date.now();
  const norm=normalizeUrl(targetUrl);
  if(!norm) return {status:false,error:'Link gak valid. Contoh: https://whatsapp.com/channel/0029VbDyL6d9RZAh3JjEM325/158'};
  const emojiStr=parseEmojis(reactionInput);
  if(!emojiStr) return {status:false,error:'Emoji gak valid. Contoh: 👍 atau 😂,❤️,🔥'};
  
  const state=loadState();
  let attempts=0, lastErr='Semua key limit';
  while(attempts<state.keys.length){
    const cur=state.keys[state.keyIndex%state.keys.length];
    state.keyIndex=(state.keyIndex+1)%state.keys.length;
    saveState(state);
    try{
      const result=await sendReactionRequest(norm,emojiStr,cur);
      if(result && (result.success===true || result.status==='success')){
        return {status:true,time:`${Date.now()-start}ms`,message:result.message,data:{target:norm,emojis:result.data?.task?.reaction_code||emojiStr,vip_key:cur.name,package:result.data?.vip?.packageName||'VIP'}};
      }
      if(result?.error) lastErr=result.error;
    }catch(err){ lastErr=err.response?.data?.error||err.message; }
    attempts++;
  }
  return {status:false,error:lastErr,time:`${Date.now()-start}ms`};
}

module.exports={
  name:'rch',
  command:['rch','reactch','rchvip','reactionch'],
  category: 'tools',
  desc: 'Reaction Channel VIP by IzzXd',
  usage: '.rch <link> <emoji>',
  run: async ({sock,msg,from,args,text,prefix,reply})=>{
    if(!text) return reply(`*RCH VIP*\n\n${prefix}rch https://whatsapp.com/channel/0029VbDyL6d9RZAh3JjEM325/158 👍\n${prefix}rch <link> 😂,❤️,🔥\nMax 5 emoji, by IzzXd`);
    
    let url = args.find(a=>a.includes('whatsapp.com/channel'));
    let emoji = '👍';
    if(url){
      let idx=text.indexOf(url)+url.length;
      emoji=text.slice(idx).trim()||'👍';
    } else {
      return reply('❌ Link mana? Contoh: .rch https://whatsapp.com/channel/0029VbDyL6d9RZAh3JjEM325/158 👍');
    }

    await reply(`⏳ *RCH VIP...*\nTarget: ${url}\nEmoji: ${emoji}\nAntre ke API...`);
    
    const res=await react(url,emoji);
    if(!res.status) return reply(`❌ *GAGAL*\n${res.error}\nTime: ${res.time}`);
    return reply(`✅ *RCH SUCCESS*\n\n⏱️ ${res.time}\n🔗 ${res.data.target}\n😀 ${res.data.emojis}\n🔑 ${res.data.vip_key}\n📦 ${res.data.package}\n\n${res.message}\n\n_Cek channel 10-30 detik_`);
  }
};
