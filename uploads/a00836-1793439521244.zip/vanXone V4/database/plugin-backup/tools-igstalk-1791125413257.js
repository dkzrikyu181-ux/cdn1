const axios = require("axios");
const cheerio = require("cheerio");

function formatCount(n) {
  if (!n || isNaN(n)) return "0";
  if (n >= 1e9) return (n / 1e9).toFixed(1) + "M";
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "jt";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "rb";
  return String(n);
}
function parseMetric(s) {
  if (!s) return 0;
  const clean = s.replace(/,/g, "").trim();
  if (clean.endsWith("M") || clean.endsWith("m")) return Math.round(parseFloat(clean) * 1e6);
  if (clean.endsWith("K") || clean.endsWith("k")) return Math.round(parseFloat(clean) * 1e3);
  if (clean.endsWith("B") || clean.endsWith("b")) return Math.round(parseFloat(clean) * 1e9);
  return parseInt(clean, 10) || 0;
}
async function stalkInstagram(rawUsername) {
  const cleanUsername = String(rawUsername).replace(/^@+/, "").trim();
  if (!cleanUsername) throw new Error("Username tidak valid!");
  let followers=0, followersFormatted="0", following=0, followingFormatted="0", posts=0, postsFormatted="0";
  let fullName=cleanUsername, bio="", isVerified=false, isPrivate=false, avatarUrl="", found=false;
  try{
    const embedRes = await axios.get(`https://www.instagram.com/${cleanUsername}/embed/`, {
      headers: { "User-Agent": "Mozilla/5.0" }, timeout: 8000, validateStatus: s=>s<500
    });
    const html=embedRes.data||"";
    if(embedRes.status===404) throw new Error(`@${cleanUsername} tidak ditemukan`);
    if(html.includes("followers_count")){
      found=true;
      const f=html.match(/followers_count[^\d]*(\d+)/);
      const p=html.match(/posts_count[^\d]*(\d+)/);
      if(f){ followers=parseInt(f[1]); followersFormatted=formatCount(followers); }
      if(p){ posts=parseInt(p[1]); postsFormatted=formatCount(posts); }
    }
  }catch(e){ if(e.message.includes("tidak ditemukan")) throw e; }
  try{
    const crawlerRes = await axios.get(`https://www.instagram.com/${cleanUsername}/`, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; Googlebot/2.1;)" }, timeout: 6000, validateStatus: s=>s<500
    });
    if(crawlerRes.status===200){
      const $ = cheerio.load(crawlerRes.data);
      const descMeta = $('meta[name="description"]').attr("content")||"";
      if(descMeta.includes("Followers")){
        found=true;
        const m=descMeta.match(/([0-9.,KMBkmb]+)\s+Followers,\s+([0-9.,KMBkmb]+)\s+Following,\s+([0-9.,KMBkmb]+)\s+Posts/i);
        if(m){
          followers=parseMetric(m[1]); followersFormatted=m[1];
          following=parseMetric(m[2]); followingFormatted=m[2];
          posts=parseMetric(m[3]); postsFormatted=m[3];
        }
        const ogTitle=$('meta[property="og:title"]').attr("content")||"";
        const tM=(ogTitle).match(/^(.*?)(?:\s*\(@|\s*•)/);
        if(tM) fullName=tM[1].trim();
        const bM=descMeta.match(/on Instagram:\s*"([\s\S]*?)"\s*$/);
        if(bM) bio=bM[1].trim();
        const ogImage=$('meta[property="og:image"]').attr("content")||"";
        if(ogImage) avatarUrl=ogImage;
      }
    }
  }catch{}
  if(!found) throw new Error(`@${cleanUsername} tidak ditemukan / privat`);
  return { username:cleanUsername, full_name:fullName, biography:bio, is_verified:isVerified, is_private:isPrivate, followers, followers_formatted:followersFormatted, following, following_formatted:followingFormatted, posts, posts_formatted:postsFormatted, avatar_url:avatarUrl };
}

module.exports = {
  name: 'igstalk',
  command: ['igstalk','stalkig'], // FIX: hapus 'ig' biar gak bentrok sama downloader/ig.js
  category: 'tools',
  desc: 'Stalk IG by vanXone',
  creator: 'vanXone',
  usage: 'username',
  run: async ({ sock, msg, from, args, text, prefix, reply }) => {
    if(!text) return reply(`Contoh: ${prefix}igstalk cristiano`);
    const username=text.split(/\s+/)[0].replace('@','');
    try{
      await reply(`🔍 Stalking @${username}...`);
      const r=await stalkInstagram(username);
      let caption=`*IG STALK - by vanXone*\n\n`;
      caption+=`👤 @${r.username}\n📛 ${r.full_name}\n${r.is_verified?'✅ Verified\n':''}${r.is_private?'🔒 Private\n':'🌐 Public\n'}\n`;
      caption+=`👥 Followers: ${r.followers_formatted}\n👣 Following: ${r.following_formatted}\n📸 Posts: ${r.posts_formatted}\n`;
      if(r.biography) caption+=`\n📝 ${r.biography}\n`;
      caption+=`\n🔗 instagram.com/${r.username}`;
      if(r.avatar_url){
        await sock.sendMessage(from, { image: { url: r.avatar_url }, caption }, { quoted: msg });
      }else{ await reply(caption); }
    }catch(e){ return reply(`❌ ${e.message}`); }
  }
};
