const fs = require('node:fs')
const sharp = require('sharp')

// ============================================================
// CONSTANTS
// ============================================================
const DEFAULT_CHANNEL = '120363424132521336@newsletter'

// ============================================================
// HELPERS
// ============================================================
function formatDuration(sec) {
  sec = parseInt(sec) || 0
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60
  return h > 0 ? `${h}j ${m}m ${s}s` : m > 0 ? `${m}m ${s}s` : `${s}s`
}

function timeAgo(ts) {
  if (!ts) return '-'
  const sec = Math.floor(Date.now() / 1000 - ts)
  if (sec < 60) return `${sec}s lalu`
  if (sec < 3600) return `${Math.floor(sec / 60)}m lalu`
  if (sec < 86400) return `${Math.floor(sec / 3600)}j lalu`
  return `${Math.floor(sec / 86400)}h lalu`
}

module.exports = {
  name: 'channelstatus',
  command: ['cs', 'channelstatus', 'cscheck', 'cslist', 'csreact', 'csrevoke', 'csu', 'csupdates', 'csq', 'csquestion'],
  category: 'tools',
  desc: 'Channel Status Manager untuk posting status saluran',
  usage: '<teks> / reply media',
  owner: true,
  run: async ({ sock, msg, from, sender, args, text, prefix, reply }) => {
    const m = msg
    const conn = sock
    const usedPrefix = prefix
    const command = args[0] ? msg.message?.extendedTextMessage?.text?.split(' ')[0]?.replace(prefix, '') : m.command || ''
    // ambil command asli dari body
    const body = m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || ''
    const cmd = (body.split(' ')[0].replace(prefix, '').toLowerCase() || '').trim()
    
    // biar m.reply & m.quoted tetep jalan di system lu
    m.reply = reply
    if (!m.quoted) {
      const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage
      if (quotedMsg) {
        m.quoted = {
          message: quotedMsg,
          download: async () => {
            const { downloadMediaMessage } = require('@whiskeysockets/baileys')
            const pino = require('pino')
            return await downloadMediaMessage({ key: m.key, message: quotedMsg }, 'buffer', {}, { logger: pino({ level: 'silent' }), reuploadRequest: conn.updateMediaMessage })
          }
        }
      }
    }
    if (!m.download) {
      m.download = async () => {
        const { downloadMediaMessage } = require('@whiskeysockets/baileys')
        const pino = require('pino')
        return await downloadMediaMessage(m, 'buffer', {}, { logger: pino({ level: 'silent' }), reuploadRequest: conn.updateMediaMessage })
      }
    }

    // ============================================================
    // .cs — Posting Status Channel
    // ============================================================
    if (cmd === 'cs' || cmd === 'channelstatus') {
      if (!text) {
        return reply(
          `📌 *Channel Status Manager*\n\n` +
          `*Posting:*\n` +
          `• \`${prefix}cs <teks>\` — text\n` +
          `• Reply/kirim gambar + \`${prefix}cs <caption>\`\n` +
          `• Reply/kirim video + \`${prefix}cs <caption>\`\n\n` +
          `*Fitur lain:*\n` +
          `• \`${prefix}cscheck\` — cek izin posting\n` +
          `• \`${prefix}cslist\` — list status\n` +
          `• \`${prefix}csreact <id> <emoji>\` — react\n` +
          `• \`${prefix}csrevoke <id>\` — hapus status\n\n` +
          `*Contoh:*\n` +
          `• \`${prefix}cs Halo semua! 🌸\`\n` +
          `• Reply gambar: \`${prefix}cs Promo hari ini\``
        )
      }
      try {
        const check = await conn.newsletterCanPostStatus(DEFAULT_CHANNEL)
        if (!check?.canPost) {
          return reply(`❌ *Saluran gak punya izin Channel Status*\n\n📋 Capabilities: ${JSON.stringify(check?.capabilities || {}, null, 2)}`)
        }
      } catch (e) { console.error('[CS] cek izin:', e) }

      try {
        const q = m.quoted || m
        const hasImage = q?.message?.imageMessage
        const hasVideo = q?.message?.videoMessage
        const hasAudio = q?.message?.audioMessage
        const hasGif = q?.message?.videoMessage?.gifPlayback

        let payload = {}
        let mediaType = 'text'

        if (hasImage) {
          const buffer = await q.download()
          payload = { image: buffer, caption: text }
          mediaType = 'image'
        } else if (hasVideo) {
          const buffer = await q.download()
          payload = { video: buffer, caption: text }
          mediaType = hasGif ? 'gif' : 'video'
        } else if (hasAudio) {
          const buffer = await q.download()
          payload = { audio: buffer }
          mediaType = 'audio'
        } else {
          payload = { text }
        }

        const posted = await conn.sendNewsletterStatus(DEFAULT_CHANNEL, payload)
        let out = `✅ *Channel Status Terkirim!*\n\n📝 *Tipe:* ${mediaType}\n🆔 *Server ID:* ${posted?.newsletterStatusServerId || 'pending'}\n📅 *Waktu:* ${new Date().toLocaleString('id-ID')}\n⏰ *Expired:* 24 jam\n\n`
        out += posted?.newsletterStatusServerId ? `💡 *Simpan ID ini* buat react/revoke:\n\`${posted.newsletterStatusServerId}\`` : `⚠️ Server ID belum ke-detect. Coba \`${prefix}cslist\` nanti.`
        return reply(out)
      } catch (e) { return reply(`❌ *Gagal kirim status:*\n\n${e?.message || e}`) }
    }

    if (cmd === 'cscheck') {
      try {
        const check = await conn.newsletterCanPostStatus(DEFAULT_CHANNEL)
        let out = `🔍 *Channel Status Permission*\n\n📡 *Channel:* \`${DEFAULT_CHANNEL}\`\n\n✅ *Can Post:* ${check?.canPost ? 'Ya' : 'Tidak'}\n🎵 *Can Post Music:* ${check?.canPostMusic ? 'Ya' : 'Tidak'}\n\n`
        if (check?.capabilities) {
          out += `📋 *Capabilities:*\n`
          for (const [k, v] of Object.entries(check.capabilities)) out += `  • ${k}: ${v ? '✅' : '❌'}\n`
        }
        return reply(out)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }

    if (cmd === 'cslist') {
      try {
        const argList = text?.trim().split(/\s+/).filter(Boolean) || []
        const opts = { count: 20 }
        for (let i = 0; i < argList.length; i++) {
          if (argList[i] === '--before' && argList[i + 1]) opts.before = parseInt(argList[i + 1])
          else if (argList[i] === '--after' && argList[i + 1]) opts.after = parseInt(argList[i + 1])
          else if (argList[i] === '--count' && argList[i + 1]) opts.count = parseInt(argList[i + 1])
        }
        const result = await conn.getNewsletterStatuses(DEFAULT_CHANNEL, opts)
        const statuses = result?.statuses || []
        if (!statuses.length) return reply('📭 Belum ada status di saluran ini.')
        let out = `📊 *Channel Status List*\n\n📡 \`${DEFAULT_CHANNEL}\`\n📊 Total: ${statuses.length}\n\n`
        for (const s of statuses) {
          out += `━━━━━━━━━━━━━━━━━━\n🆔 *ID:* \`${s.serverId}\`\n📝 *Type:* ${s.type || 'unknown'}\n👁️ *Views:* ${s.viewsCount || 0}\n💬 *Responses:* ${s.responsesCount || 0}\n`
          if (s.adminProfile?.name) out += `👤 *Admin:* ${s.adminProfile.name}\n`
          if (s.reactionCounts?.length) out += `😀 *Reactions:* ${s.reactionCounts.map(r => `${r.code} × ${r.count}`).join(', ')}\n`
          if (s.timestamp) out += `🕐 *Waktu:* ${timeAgo(s.timestamp)}\n`
        }
        return reply(out)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }

    if (cmd === 'csreact') {
      const parts = text?.trim().split(/\s+/) || []
      const statusId = parseInt(parts[0])
      const emoji = parts[1]
      if (!statusId) return reply(`📌 *React Channel Status*\n\n• \`${prefix}csreact <id> <emoji>\`\n• \`${prefix}csreact <id> off\` — hapus reaction`)
      try {
        let reaction = emoji
        if (!reaction || reaction === 'off' || reaction === '0') reaction = undefined
        await conn.sendNewsletterStatusReaction(DEFAULT_CHANNEL, statusId, reaction)
        return reply(reaction ? `✅ Reaction *${reaction}* terkirim ke status #${statusId}` : `✅ Reaction dihapus dari status #${statusId}`)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }

    if (cmd === 'csrevoke') {
      const statusId = parseInt(text?.trim())
      if (!statusId) return reply(`📌 *Revoke Channel Status*\n\n• \`${prefix}csrevoke <id>\``)
      try {
        await conn.revokeNewsletterStatus(DEFAULT_CHANNEL, statusId)
        return reply(`✅ Status #${statusId} berhasil dihapus.`)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }

    if (cmd === 'csu' || cmd === 'csupdates') {
      try {
        const argList = text?.trim().split(/\s+/).filter(Boolean) || []
        const opts = { count: 20 }
        for (let i = 0; i < argList.length; i++) {
          if (argList[i] === '--since' && argList[i + 1]) opts.since = parseInt(argList[i + 1])
          else if (argList[i] === '--count' && argList[i + 1]) opts.count = parseInt(argList[i + 1])
          else if (!isNaN(argList[i])) opts.since = parseInt(argList[i])
        }
        if (!opts.since) opts.since = Math.floor(Date.now() / 1000) - 86400
        const updates = await conn.getNewsletterStatusUpdates(DEFAULT_CHANNEL, opts)
        let out = `📡 *Channel Status Updates*\n\n📅 Since: ${new Date(opts.since * 1000).toLocaleString('id-ID')}\n📊 Total: ${updates?.length || 0}\n\n`
        out += !updates?.length ? `_Gak ada update._` : updates.map(u => `• \`${u.serverId || '-'}\` — ${u.type || '-'}`).join('\n')
        return reply(out)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }

    if (cmd === 'csq' || cmd === 'csquestion') {
      const q = m.quoted || m
      if (!q?.message?.imageMessage) return reply(`📌 *Question Status*\n\nQuestion status *HARUS* di atas media.\n• Reply gambar + \`${prefix}csq <pertanyaan>\``)
      try {
        const buffer = await q.download()
        const posted = await conn.sendNewsletterStatus(DEFAULT_CHANNEL, { image: buffer, caption: text || '', question: { text: text || 'Tanya apa saja' } })
        return reply(`✅ *Question Status Terkirim!*\n\n🆔 Server ID: \`${posted?.newsletterStatusServerId || 'pending'}\`\n❓ Question: ${text || 'Tanya apa saja'}`)
      } catch (e) { return reply(`❌ ${e?.message || e}`) }
    }
  }
}
