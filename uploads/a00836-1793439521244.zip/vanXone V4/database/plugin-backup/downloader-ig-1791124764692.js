const { getUrl, hostIs, maxItems } = require('../../lib/downloader')
const { fetchAndSend } = require('../../lib/mediadl')

module.exports = {
  name: 'ig',
  command: ['ig', 'igdl', 'instagram'],
  category: 'downloader',
  desc: 'Download reel/foto/carousel Instagram',
  usage: '<link>',
  run: async ({ sock, msg, from, args, prefix, reply }) => {
    const url = getUrl(args)
    if (!url || !hostIs(url, ['instagram.com'])) {
      return reply(`Masukkan link postingan Instagram.\nContoh: ${prefix}ig https://www.instagram.com/reel/xxxx`)
    }

    await reply('⏳ Mengunduh dari Instagram...')
    try {
      await fetchAndSend(sock, from, msg, url, { playlist: true, max: maxItems(), caption: '*INSTAGRAM DOWNLOADER*' })
    } catch (err) {
      await reply(`❌ ${err.message}`)
    }
  }
}
