// Pembuat gambar: fake chat (qc/iqc), tweet, komentar YouTube, code snapshot, layar telepon
const kit = require('../../lib/kit')
const M = require('../../lib/anya_maker')
const { getUser } = require('../../lib/db')
const { getContextInfo, getQuotedText, userOf } = require('../../lib/utils')

const bad = (m) => Object.assign(new Error('arg'), { userMessage: m })
const rest = (c) => kit.rest(c.body).trim()

// siapa "pembicara": orang yang di-reply / dimention, kalau tidak ada = pengirim
async function who(c, explicitName) {
  const ci = getContextInfo(c.msg) || {}
  const jid = ci.quotedMessage && ci.participant ? ci.participant : ci.mentionedJid?.[0] || c.sender
  let name = explicitName || (jid === c.sender ? c.msg.pushName : '') || getUser(jid).name || userOf(jid)
  let url = null
  try { url = await c.sock.profilePictureUrl(jid, 'image') } catch {}
  return { jid, name: String(name).slice(0, 30), url, replied: ci.quotedMessage ? getQuotedText(c.msg) : '' }
}
const splitName = (c) => { const r = rest(c); const i = r.indexOf('|'); return i > 0 ? { name: r.slice(0, i).trim(), text: r.slice(i + 1).trim() } : { name: '', text: r } }
const sendSticker = async (c, png) => { await c.sock.sendMessage(c.from, { sticker: await M.toSticker(png) }, { quoted: c.msg }); return null }

const specs = {
  qc: { desc: 'Bikin sticker kutipan chat gelap (reply pesan, atau tulis teks). Format: [nama |] teks', usage: '[nama |] <teks>', example: 'Budi | halo semua', heavy: true, optional: true, run: async (c) => {
    const { name, text } = splitName(c); const w = await who(c, name); const t = text || w.replied
    if (!t) throw bad('Tulis teks atau reply pesan yang mau dikutip.')
    return sendSticker(c, await M.qc({ name: w.name, text: t, avatarUrl: w.url }))
  } },
  qcimg: { desc: 'Sama seperti qc tapi dikirim sebagai gambar HD (bukan stiker)', usage: '[nama |] <teks>', heavy: true, optional: true, run: async (c) => {
    const { name, text } = splitName(c); const w = await who(c, name); const t = text || w.replied
    if (!t) throw bad('Tulis teks atau reply pesan.')
    return { image: await M.qc({ name: w.name, text: t, avatarUrl: w.url }), caption: '' }
  } },
  iqc: { desc: 'Chat bergaya iMessage di layar iPhone (jam & baterai bisa diatur)', usage: '<teks> [| jam | baterai]', example: 'Oke siap | 09:41 | 80', heavy: true, args: true, run: async (c) => {
    const [t, time, bat] = rest(c).split('|').map((s) => s.trim())
    if (!t) throw bad('Tulis teks pesannya.')
    return { image: await M.iqc({ text: t, time: /^\d{1,2}:\d{2}$/.test(time || '') ? time : undefined, battery: Math.min(100, Math.max(1, parseInt(bat) || 78)) }), caption: '' }
  } },
  faketweet: { desc: 'Bikin tangkapan tweet/postingan X palsu untuk bercanda', usage: '[nama |] <teks>', example: 'Budi | Hari Senin lagi…', heavy: true, args: true, run: async (c) => {
    const { name, text } = splitName(c); const w = await who(c, name); const t = text || w.replied
    if (!t) throw bad('Tulis isi tweet.')
    const seed = [...t].reduce((a, ch) => a + ch.charCodeAt(0), 0)
    return { image: await M.tweet({ name: w.name, user: w.name.replace(/\s+/g, '').toLowerCase() || 'user', text: t, avatarUrl: w.url, likes: 120 + (seed % 9000), rts: 20 + (seed % 700) }), caption: '🐦 _Tampilan ini hanya hiburan (parodi)._' }
  } },
  ytcomment: { desc: 'Bikin tangkapan komentar YouTube (mode gelap)', usage: '[nama |] <komentar>', example: 'Budi | Lagu ini bikin nostalgia', heavy: true, args: true, run: async (c) => {
    const { name, text } = splitName(c); const w = await who(c, name); const t = text || w.replied
    if (!t) throw bad('Tulis komentarnya.')
    return { image: await M.ytcomment({ name: w.name, text: t, avatarUrl: w.url, likes: 12 + (t.length * 13) % 900 }), caption: '' }
  } },
  codesnap: { desc: 'Ubah kode jadi gambar cantik bergaya editor (tulis kode atau reply pesan berisi kode)', usage: '<kode>', example: 'console.log("halo")', heavy: true, optional: true, run: async (c) => {
    const code = (kit.rest(c.body) || '').replace(/^\s*\n/, '') || getQuotedText(c.msg) || ''
    if (!code.trim()) throw bad('Tulis kodenya atau reply pesan berisi kode.')
    return { image: await M.codesnap({ code: code.replace(/^```\w*\n?|```$/g, '') }), caption: '' }
  } },
  wacall: { desc: 'Bikin layar panggilan WhatsApp (masuk/keluar) untuk iseng', usage: '[masuk|keluar] [nama]', example: 'masuk Mama', heavy: true, optional: true, run: async (c) => {
    const first = (c.args[0] || '').toLowerCase(); const mode = ['masuk', 'keluar'].includes(first) ? first : 'masuk'
    const nameArg = (mode === first ? c.args.slice(1) : c.args).join(' ').trim()
    const w = await who(c, nameArg)
    return { image: await M.wacall({ name: nameArg || w.name, avatarUrl: nameArg ? null : w.url, mode }), caption: '' }
  } }
}
delete specs.qc // .qc kini dari plugins/sticker/qc.js (plugin baru)
module.exports = kit.multi({ name: 'anya-maker', category: 'image', emoji: '🎭', desc: 'Fake chat/iPhone, tweet, komentar YouTube, code snapshot, layar telepon', specs, alias: { fakeiphonechat: 'iqc', fakecall: 'wacall' } })
