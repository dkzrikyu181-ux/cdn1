/**
 * RCH VIP FIX - Anti "Akses Ditolak"
 * Fix: auto sync key dari Firebase + force Origin
 */

const fs = require('fs');
const path = require('path');
const axios = require('axios');

const API_ENDPOINT = 'https://apiv2.reactionwa.online/api/v2/react';
const FIREBASE_API_KEY = 'AIzaSyDNbAlgLycK0oRO8I9ja3mPnIccZkOz0M0';
const RTDB_URL = 'https://autoreactberry-default-rtdb.asia-southeast1.firebasedatabase.app/api_keys.json';
const CACHE_DIR = path.join(__dirname, '.cache');
const STATE_FILE = path.join(CACHE_DIR, 'rch_vip_state.json');
const LINK_REGEX = /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([A-Za-z0-9_-]+)\/(\d+)/i;
const EMOJI_REGEX = /\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?/gu;

// Key fallback kalau Firebase mati
const DEFAULT_VIP_KEYS = [
    { name: 'VIP-SYNOZG8C', apiKey: 'EmCRdHArrxyMxWgwZVbukIcXOFGgz05PleSnm/5E6lP/MNb9rI4R/fqR5ALvCRhe3Q0NmDMw7lBXprFV3w8jen1M', domain: 'https://reactionwa.online' }
];

function ensureCacheDir(){ if(!fs.existsSync(CACHE_DIR)){ try{ fs.mkdirSync(CACHE_DIR,{recursive:true}); }catch{} } }
function loadState(){ ensureCacheDir(); let s={keyIndex:0,keys:DEFAULT_VIP_KEYS,lastSync:0}; if(fs.existsSync(STATE_FILE)){ try{ const j=JSON.parse(fs.readFileSync(STATE_FILE,'utf8')); if(j.keys) s=j; }catch{} } return s; }
function saveState(s){ ensureCacheDir(); try{ fs.writeFileSync(STATE_FILE,JSON.stringify(s,null,2)); }catch{} }

async function syncVipKeys(){
    try{
        const authRes = await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${FIREBASE_API_KEY}`, {returnSecureToken:true}, {headers:{'Referer':'https://reactionwa.online/'}, timeout:10000});
        const idToken = authRes.data?.idToken;
        if(!idToken) return null;
        const dbRes = await axios.get(`${RTDB_URL}?auth=${idToken}`, {timeout:10000});
        if(!dbRes.data || typeof dbRes.data!=='object') return null;
        const fresh=[];
        for(const [name,val] of Object.entries(dbRes.data)){
            if(val && val.active!==false && val.apiKey){
                fresh.push({name,apiKey:val.apiKey,domain:val.domain==='*'?'https://reactionwa.online':(val.domain||'https://reactionwa.online')});
            }
        }
        if(fresh.length>0){
            const state=loadState();
            state.keys=fresh; state.lastSync=Date.now(); saveState(state);
            return fresh;
        }
    }catch(e){ console.log('sync failed',e.message); }
    return null;
}

function normalizeUrl(u){ const m=String(u||'').match(LINK_REGEX); if(!m) return null; return `https://whatsapp.com/channel/${m[1]}/${m[2]}`; }
function parseEmojis(e){ const m=String(e||'').match(EMOJI_REGEX); if(!m) return null; return m.slice(0,5).join(', '); }

async function sendReactionRequest(t,r,k){
    // FIX UTAMA: Paksa origin jadi https://reactionwa.online biar ke-whitelist
    const origin = 'https://reactionwa.online';
    const referer = 'https://reactionwa.online/';
    const res=await axios.post(API_ENDPOINT,{url:t,reaction:r},{
        headers:{
            'Content-Type':'application/json',
            'Origin': origin,
            'Referer': referer,
            'x-api-key': k.apiKey,
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/129.0.0.0 Safari/537.36'
        },
        timeout:45000
    });
    return res.data;
}

async function react(targetUrl,reactionInput){
    const start=Date.now();
    const norm=normalizeUrl(targetUrl);
    if(!norm) return {status:false,error:'Link gak valid'};
    const emojiStr=parseEmojis(reactionInput);
    if(!emojiStr) return {status:false,error:'Emoji gak valid'};

    // Coba sync key baru dulu
    await syncVipKeys();
    const state=loadState();
    
    let attempts=0, lastErr='Semua key limit / whitelist error';
    while(attempts<state.keys.length){
        const cur=state.keys[state.keyIndex%state.keys.length];
        state.keyIndex=(state.keyIndex+1)%state.keys.length;
        saveState(state);
        try{
            const result=await sendReactionRequest(norm,emojiStr,cur);
            if(result && (result.success===true || result.status==='success')){
                return {status:true,time:`${Date.now()-start}ms`,message:result.message,data:{target:norm,emojis:result.data?.task?.reaction_code||emojiStr,key:cur.name}};
            }
            if(result?.error) lastErr=result.error;
        }catch(err){ lastErr=err.response?.data?.error||err.message; }
        attempts++;
    }
    return {status:false,error:lastErr,time:`${Date.now()-start}ms`};
}

module.exports={
  name:'rch',
  command:['rch','reactch','rchvip','rchsync'],
  category:'tools',
  desc:'RCH VIP FIX whitelist',
  run: async ({sock,from,text,prefix,reply})=>{
    if(!text) return reply(`*RCH VIP FIX*\n${prefix}rch https://whatsapp.com/channel/ID/POSTID 👍\n${prefix}rchsync = sync key baru`);
    
    if(text.trim().toLowerCase()==='sync' || prefix+'rchsync'==text.trim().split(' ')[0]){
        await reply('⏳ Sync VIP keys dari Firebase...');
        const fresh=await syncVipKeys();
        if(fresh) return reply(`✅ Sync berhasil: ${fresh.length} key aktif\n${fresh.map(k=>'- '+k.name).join('\\n')}`);
        return reply('❌ Sync gagal, pake key lama');
    }

    let url=text.match(/https?:\/\/whatsapp\.com\/channel\/[^\s]+/i)?.[0];
    let emoji=text.replace(url,'').trim()||'👍';
    if(!url) return reply('❌ Link mana? Contoh: .rch https://whatsapp.com/channel/0029Vb7JOvhEwEjnQgO8Ui3d/232 🎶');
    
    await reply(`⏳ *RCH...*\\n${url}\\n${emoji}\\nSync & kirim...`);
    const res=await react(url,emoji);
    if(!res.status) return reply(`❌ *GAGAL*\n${res.error}\nTime: ${res.time}\n\nCoba:\n1. .rchsync dulu\n2. Ganti emoji simple (👍 ❤️ 🔥)\n3. Coba 1 menit lagi`);
    return reply(`✅ *RCH SUCCESS*\n⏱️ ${res.time}\n🔗 ${res.data.target}\n😀 ${res.data.emojis}\n🔑 ${res.data.key}\n\n${res.message}`);
  }
};
