// .chreact — beri reaksi emoji ke pesan di saluran (dari link pesan)
const ch = require('../../lib/channels')

module.exports = {
  name: 'chreact',
  command: ['chreact', 'reactch'],
  category: 'channel',
  emoji: '😍',
  desc: 'Reaksi emoji ke pesan saluran (pakai link pesan)',
  usage: '<link pesan saluran> <emoji>',
  owner: true,
  run: async ({ sock, body, prefix, reply }) => {
    const [link, emoji] = String(body || '').replace(/^\S+\s*/, '').trim().split(/\s+/)
    try {
      ch.need(sock, 'newsletterReactMessage')
      const ref = ch.parseRef(link)
      if (!ref || !ref.serverId || !emoji) {
        return reply(`Format: ${prefix}chreact <link pesan> <emoji>\nLink pesan: buka pesan di saluran → bagikan/salin tautan (berakhiran angka).\nContoh: ${prefix}chreact https://whatsapp.com/channel/0029VaXXXX/123 ❤️`)
      }
      if (emoji.length > 8) return reply('Emoji tidak valid.')
      const md = await ch.metadata(sock, ref)
      await sock.newsletterReactMessage(md.id, ref.serverId, emoji)
      await reply(`✅ Reaksi ${emoji} terkirim ke pesan #${ref.serverId} di *${md.name}*.`)
    } catch (err) {
      console.log('[CH] chreact:', err.message)
      await reply(`❌ ${ch.explain(err)}`)
    }
  }
}
