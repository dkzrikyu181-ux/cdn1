// Port dari Ourin (canvas/iqc.js). Kode asli utuh di ourin/plugins/canvas/iqc.js; dijalankan lewat lib/ourin.js.
module.exports = require('../../../lib/ourin').plugin("canvas/iqc", {
  "name": "iqc",
  "command": [
    "iqc",
    "qc2"
  ],
  "category": "canvas",
  "desc": "Membuat Fake Quote iOS style secara instan.",
  "usage": ".iqc [text/reply]",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 2,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
})
